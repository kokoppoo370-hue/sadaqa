// service-worker.js
const CACHE_VERSION = 'noor-v5'; // ★ غيّر الرقم ده (v1, v2, v3...) كل ما تعمل تحديث ★
const CACHE_FILES = [
  './',
  './index.html',
  './manifest.json',
  './icon-72.png',
  './icon-96.png',
  './icon-192.png',
  './icon-512.png'
  // لو عندك أي ملفات إضافية (CSS, JS خارجية), ضيفها هنا
];

// تثبيت الـ SW
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => {
      return cache.addAll(CACHE_FILES);
    }).then(() => {
      return self.skipWaiting(); // تفعيل فوري
    })
  );
});

// تنشيط الـ SW ومسح الكاش القديم
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_VERSION) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => {
      return clients.claim(); // التحكم في الصفحات المفتوحة
    })
  );
});

// استراتيجية جلب الملفات (من النت أولاً، ثم الكاش)
self.addEventListener('fetch', (event) => {
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const responseClone = response.clone();
        caches.open(CACHE_VERSION).then((cache) => {
          cache.put(event.request, responseClone);
        });
        return response;
      })
      .catch(() => {
        return caches.match(event.request);
      })
  );
});

// استقبال رسالة التحديث من الصفحة
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});